package bank;

import java.util.ArrayList;

public class BankAccount {
private String status = ""; 
private int accountNum;
private double balance;
private ArrayList <String> transactions;
private ArrayList <String> transactionsSummary;
private int numOfTransactions;

	
public BankAccount(int abc, double xyz){
    accountNum = abc;
    balance = xyz;
    status = "open";  
    transactionsSummary = new ArrayList<String>();
    transactions = new ArrayList<String>();
    transactions.add("\nInitial Balance : $" + Double.toString(balance));
    transactionsSummary.add("A balance of : $" + Double.toString(balance) + " was deposited.");
    numOfTransactions = 1;
  }

public void deposit(double amount){

    if (amount<=0) {
        System.out.println("Amount to be deposited should be positive");
    } else {
        balance = balance + amount;
        transactions.add("\n"+ Integer.toString(numOfTransactions)+". $" + Double.toString(amount));
        transactionsSummary.add("$" + Double.toString(amount) + " was deposited.");
        numOfTransactions++;
    }
}

public void withdraw(double amount)
{
    if (amount<=0){
         System.out.println("Amount to be withdrawn should be positive");
     }
    else
    {
        if (balance < amount) {
            System.out.println("Insufficient balance");
        } else {
            balance = balance - amount;
            transactions.add("\n"+ Integer.toString(numOfTransactions)+". -$" + Double.toString(amount));
            transactionsSummary.add(Integer.toString(accountNum));
            numOfTransactions++;
        }
    }
}

public String getTransactions(){
	 String tsc = "\nAccount "+ "#"+ this.accountNum + " transactions:";
			for (String transaction : transactions)
			{
				tsc += transaction;
			}
	return tsc+"\nEnd of Transactions";
	
}

public int retrieveNumberOfTransactions(){
	return this.numOfTransactions;
}

   public int getAccountNum(){
	   return accountNum;
   }
   
   public double getBalance(){
	   return balance;
   }
   
   public void suspend (){
	  if(isClosed()== false)
		  setStatus("suspended") ;
   } 
   
   //If not already closed, reopen account and call withdraw()to withdraw the
   //current balance.
   public void close (){
	if(isClosed()== false){
		reOpen();
		this.withdraw(this.balance);				
		setStatus("closed");
	}
   } 
   
   public void reOpen (){
	   if(isSuspended()== true)
		   setStatus("open");		   
   } 
 
   public boolean isOpen(){
	   if("open".equals(this.status))
		   return true;
	   else 
		   return false;
   }
   
   public boolean isSuspended() {
	   if("suspended".equals(this.status))
		   return true;
	   else 
		   return false;
   }
   
   public boolean isClosed(){
	   if("closed".equals(this.status))
		   return true;
	   else 
		   return false;
		   
   }
                          
private void setStatus (String status){
	this.status = status;
}
	
public String getStatus (){
	return status;
	
}

	}


