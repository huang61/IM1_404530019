package bank;

import java.util.ArrayList;

public class Bank {
	
	private ArrayList<BankAccount> accounts;     // all the bank accounts at this bank
	
	public Bank() {
	    accounts = new ArrayList<BankAccount>();
	    
	    }

	public int addAccount(int accountNumber , double initialBalance) {
	    BankAccount b = new BankAccount(accountNumber, initialBalance);
	    accounts.add(b);	    
	    return accountNumber;
	}
	
	//Used the enhanced for loop for all loop implementations. 
	public void deposit(int accountNumber, double initialBalance){		
		for (BankAccount account : accounts){
	        if (accountNumber == account.getAccountNum()&& account.isOpen()== true)
	         account.deposit(initialBalance);
	            }           
	 }	
	
	public void withdraw(int accountNumber, double initialBalance){
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum()&& account.isOpen()== true)
        	account.withdraw(initialBalance);
        	   }            
	 }
	    	    
	
	public double getBalance(int accountNumber) {
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum())
        		return account.getBalance();
        }
		return 0;
	        }
	
	public void suspendAccount(int accountNumber){
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum())
        		account.suspend();
	        }
	
	}
		
	public void reOpenAccount(int accountNumber){
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum())
        		account.reOpen();
		}
	}	
	
	public void closeAccount(int accountNumber){
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum())
        		account.close();
		}
	        }
	
	public String getAccountStatus(int accountNumber){
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum())
        		return account.getStatus();
		}
		return "Account not found";
	        }
	
	
	public String summarizeAccountTransactions(int accountNumber){
		for (BankAccount account : accounts){
        	if (accountNumber == account.getAccountNum())
        		return account.getTransactions();
		}        
		return "Account not found";
	        	}				
	
	public String summarizeAllAccounts(){
		String sum = "\nBank Account Summary\n\nAccount\t\tBalance\t\t#Transactions\t\tStatus";
		 for( BankAccount account : accounts )
		 {
			 sum +="\n"+account.getAccountNum()+ "\t\t" + account.getBalance()+ "\t\t" + 
				   account.retrieveNumberOfTransactions()+ "\t\t\t" + account.getStatus();	 
		 }
		
		return sum;
	}
		
}

